1	/artifact/org.wso2.carbon/org.wso2.carbon.databridge.agent.thrift
2	#DEP# serial
3	#DEP# protocol
4	#DEP# thrift
5	#DEP# agent
