1	/artifact/com.liferay/com.liferay.portal.dao.orm.custom.sql
2	#DEP# orm
3	#DEP# sql
4	#DEP# persist
5	#DEP# dao
6	#DEP# portal
