1	/artifact/org.wso2.carbon.analytics-common/org.wso2.carbon.databridge.commons.thrift
2	#DEP# serial
3	#DEP# protocol
4	#DEP# thrift
5	#DEP# analyt
