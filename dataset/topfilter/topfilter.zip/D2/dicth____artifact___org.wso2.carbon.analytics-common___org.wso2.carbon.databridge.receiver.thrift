1	/artifact/org.wso2.carbon.analytics-common/org.wso2.carbon.databridge.receiver.thrift
2	#DEP# thrift
3	#DEP# protocol
4	#DEP# analyt
5	#DEP# serial
