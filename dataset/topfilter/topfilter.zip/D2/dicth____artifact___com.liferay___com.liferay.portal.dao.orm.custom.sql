1	/artifact/com.liferay/com.liferay.portal.dao.orm.custom.sql
2	#DEP# persist
3	#DEP# orm
4	#DEP# dao
5	#DEP# sql
6	#DEP# portal
