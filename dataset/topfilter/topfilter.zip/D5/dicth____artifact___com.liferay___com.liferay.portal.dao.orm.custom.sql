1	/artifact/com.liferay/com.liferay.portal.dao.orm.custom.sql
2	#DEP# persist
3	#DEP# portal
4	#DEP# sql
5	#DEP# dao
6	#DEP# orm
