1	/artifact/org.wso2.carbon.analytics-common/org.wso2.carbon.databridge.commons.thrift
2	#DEP# thrift
3	#DEP# analyt
4	#DEP# protocol
5	#DEP# serial
