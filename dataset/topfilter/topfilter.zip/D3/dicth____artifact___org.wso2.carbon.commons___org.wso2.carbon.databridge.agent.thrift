1	/artifact/org.wso2.carbon.commons/org.wso2.carbon.databridge.agent.thrift
2	#DEP# thrift
3	#DEP# protocol
4	#DEP# agent
5	#DEP# serial
