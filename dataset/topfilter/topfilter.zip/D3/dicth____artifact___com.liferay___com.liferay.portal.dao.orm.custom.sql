1	/artifact/com.liferay/com.liferay.portal.dao.orm.custom.sql
2	#DEP# persist
3	#DEP# orm
4	#DEP# portal
5	#DEP# dao
6	#DEP# sql
