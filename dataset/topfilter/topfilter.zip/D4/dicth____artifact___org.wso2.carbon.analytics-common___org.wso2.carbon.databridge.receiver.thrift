1	/artifact/org.wso2.carbon.analytics-common/org.wso2.carbon.databridge.receiver.thrift
2	#DEP# protocol
3	#DEP# thrift
4	#DEP# serial
5	#DEP# analyt
