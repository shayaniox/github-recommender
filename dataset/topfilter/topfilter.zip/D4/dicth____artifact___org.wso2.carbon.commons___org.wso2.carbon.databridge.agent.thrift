1	/artifact/org.wso2.carbon.commons/org.wso2.carbon.databridge.agent.thrift
2	#DEP# protocol
3	#DEP# thrift
4	#DEP# serial
5	#DEP# agent
