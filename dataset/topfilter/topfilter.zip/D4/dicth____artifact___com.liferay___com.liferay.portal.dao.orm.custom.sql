1	/artifact/com.liferay/com.liferay.portal.dao.orm.custom.sql
2	#DEP# dao
3	#DEP# orm
4	#DEP# persist
5	#DEP# sql
6	#DEP# portal
